import React, { Component } from 'react';

// intl messages
import IntlMessages from 'Util/IntlMessages';

import FooterLogo from '../../assets/img/Fortna_WES_logo_Grey.png';
	
class Footer extends React.Component {
    render(){
      return(
        <div>
          <div className="footergap">&nbsp;</div>
            <div className="footer">
              @2018 FORTNA INC. <IntlMessages id={'Dashboard.Footer.Rights'} />.
            <div className="powered"><IntlMessages id={'Dashboard.Footer.Powered'} /> &nbsp; <img src={FooterLogo} /></div>
          </div>
        </div>
		  );
    }
  }
export default Footer;
