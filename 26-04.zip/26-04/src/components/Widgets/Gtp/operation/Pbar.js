
import React, { Component } from 'react';
import PropTypes from 'prop-types';

import { connect } from 'react-redux';  // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component

// helpers
import { hexToRgbA } from 'Helpers/helpers';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';
import { ProgressBar } from 'react-bootstrap';
import Grid from '@material-ui/core/Grid';

import Spinner from 'Util/Spinner';


class Pbar extends Component {

	render() {
	
		const { isColorBlind, percentage, barColor } = this.props;
		let lag = 10;
		let success = 10;
		let rem =  100 - lag;
		let successPerc = percentage;
		let pointerPerc = percentage - 10 ;
		let lagPerc = percentage + 10;
		let timePerc = percentage;
		
		const customWidth = {
			left: percentage+'%'
		}
		const customWidthGreen = {
			left: successPerc+'%'
		}
		const customWdthPntr = {
			left: pointerPerc+'%'
		}
		const customWidthRed = {
			left: lagPerc +'%'
		}
		const customMarginTime = {
			marginLeft: timePerc +'%'
		};
		
		let bluecolorop = barColor;
		let greencolorp = "#03b819";
		if(isColorBlind){	
			bluecolorop = "#12a8f5";
			greencolorp ="#828275";
		}

		return (
			<RctCollapsibleCard colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full opcontainer" heading="" key="" fullBlock >
				<Grid item xs={12} sm={12}>
					<div className="opProgressbar">
						<div className="customBar station-status-textblack" style={customWdthPntr} >{percentage}%</div>	
						<div className="customBar" style={customWdthPntr} >&#x2BC6;</div>	
						<ProgressBar>
							<ProgressBar  style={{height:'7px', backgroundColor: bluecolorop}} now={percentage} />
						</ProgressBar>
					</div>
				</Grid>
				<Grid item xs={12} sm={12}>
					<div>
						<div className="customBarTime station-status-textblack opgreen" style={{ color: greencolorp }} >00:00:00 <span className="deltaHrs">hrs</span></div>	
						<div className="customBarGreen" style={{marginLeft: timePerc +'%', backgroundColor: greencolorp}} >&nbsp;</div>	
						<ProgressBar>
							<ProgressBar  style={{height:'5px', backgroundColor: bluecolorop}} now={percentage} />
						</ProgressBar>
					</div>
				</Grid>
			</RctCollapsibleCard>
		);
	}
}

Pbar.propTypes = {
	barColor: PropTypes.string,
	percentage: PropTypes.number.isRequired,
};
  
Pbar.defaultProps = {
	barColor: "#0685e3",
	percentage: 80,
};

const mapStateToProps = ({ settings }) => {
	const { isColorBlind, locale} = settings;
	return { isColorBlind, locale };
};


export default withRouter(connect(mapStateToProps)(Pbar));
//export default Pbar;

