import React, { Component } from 'react';
import BinRetrivalComponent from './BinRetrivalComponent';

//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';

class BinRetrivalContainer extends Component {
constructor(props) {
		super(props);
	}

	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getCurrentValue();

	}

	//Comparing props and triggering refresh 
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.startTime = 201903230547;//dateFormat(new Date(), "yyyymmddHHMM");
			this.getCurrentValue();
			
		}
	}
	
	getCurrentValue() {
		
	}
    render(){    	
      return(
	  <RctCollapsibleCard	colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"> 
        <div className="app-horizontal collapsed-sidebar">
        <div className="app-container">
            <div className="rct-page-wrapper">
                <div className="rct-app-content">
                    <div className="app-header">
                      <div className="componentbg overall-work-monitor">
							          <BinRetrivalComponent />
							        </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
			 </RctCollapsibleCard> 
                      
      );
    }
  }
export default BinRetrivalContainer;
