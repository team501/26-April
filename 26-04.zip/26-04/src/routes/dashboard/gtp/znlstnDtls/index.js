/**
 * Data Table
 */
import React from 'react';
import { connect } from 'react-redux'; // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component 

import IconButton from '@material-ui/core/IconButton';
//axios call
import axios from 'axios';
import {graphQlURLPrd} from 'GraphQlUrl/Config';

import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';

// page title bar
import PageTitleBar from 'Components/PageTitleBar/PageTitleBar';

// rct card box
import { RctCard, RctCardContent } from 'Components/RctCard'; 

// intl messages
import IntlMessages from 'Util/IntlMessages';
import NumberClass, { NumberFormatter } from 'Util/NumberClass';

//Reloadable card
import {WatchesWidget} from "Components/Widgets";

//Bootstrap datatable custom cell style
import BootstrapTable  from 'react-bootstrap-table-next';
import MUIDataTable from "mui-datatables";
import {createMuiTheme, MuiThemeProvider, withStyles} from '@material-ui/core/styles';


import paginationFactory from 'react-bootstrap-table2-paginator';
import ToolkitProvider, { Search } from 'react-bootstrap-table2-toolkit';
import cellEditFactory from 'react-bootstrap-table2-editor';
//font-awesome icon
import "font-awesome/css/font-awesome.css";

// For Tab
import Paper from '@material-ui/core/Paper';

import Spinner from 'Util/Spinner';


import PropTypes from 'prop-types';

import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import NoSsr from '@material-ui/core/NoSsr';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';

//For Drop Down menu


///////////////////
import Toolbar from '@material-ui/core/Toolbar';
import MenuIcon from '@material-ui/icons/Menu';
import AccountCircle from '@material-ui/icons/AccountCircle';
import Switch from '@material-ui/core/Switch';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormGroup from '@material-ui/core/FormGroup';
import MenuItem from '@material-ui/core/MenuItem';
import Menu from '@material-ui/core/Menu';
////////////////////////

import InfiniteScroll from 'react-infinite-scroller';

const { SearchBar, ClearSearchButton } = Search;

import filterFactory, { textFilter } from 'react-bootstrap-table2-filter';

function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 * 3 }}>
      {props.children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

function LinkTab(props) {
  return <Tab component="a" onClick={event => event.preventDefault()} {...props} />;
}

 const styles = theme => ({
  customTab: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
  grow: {
    flexGrow: 1,
  },
  menuButton: {
    marginLeft: -12,
    marginRight: 20,
  },
});  


class ZonalNStationDtls extends React.Component {
	
	constructor(props) {
		super(props);
		this.state = {
			value: this.props.match.params.operationStatus,
			zone: "all",
			isLoading:true,
			data:[],
		};

	}
	
	handleChange = (event, value) => {
		if (typeof value != "string"){
			return;
		}
		this.setState({ value });
		this.getGTPStationDetails(value, this.state.zone);
	};			

	handleChangeDropDown = (event, value) => {
		this.setState({ zone: value.props.value });
		this.getGTPStationDetails(this.state.value, value.props.value);
	};

	componentDidMount() {
		this.onReload();
	}
	
	onReload = () => {
		this.getGTPStationDetails(this.state.value, this.state.zone); 
	}
			
	getGTPStationDetails = (operation, zone) => {
		let startTime = 201903181431;//dateFormat(new Date(), "yyyymmddHHMM");
		let zoneId = zone;
		let functionVar = operation;
	console.log("Before Query")
		/*All Stations*/
		let query = 'query getNumberOfBinsProcessed($startTime: Long!, $zoneId: String!, $functionVar: String!) { getGTPStationDetails( startTime: $startTime, xMins: 60, zoneId: $zoneId, function: $functionVar ) { stationId status stationRunTime operatorName operatorRunTime dwellTime itemsCompleted throughput productivity }}';
		fetch(graphQlURLPrd, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json'},
											   body: JSON.stringify({ query, variables: { startTime, zoneId, functionVar} })
		}).then(r => r.json())
		.then(data => { 
				this.setState(
					{ 
						getGTPStationDetails: data.data.getGTPStationDetails.map(element => [element.stationId, 
							element.status, element.stationRunTime, element.operatorName, element.operatorRunTime, element.dwellTime,
							element.itemsCompleted, element.throughput, element.productivity]), 
						isLoading:false
					}
				);
					console.log("After Query")
					console.log(this.state.getGTPStationDetails)
		})
		.catch((error) => {
			console.log(error);
			this.setState({ getGTPStationDetails: [],
						    isLoading:false
						  }); 
		});
	}
			
			
		render() {
		
		// stationId status stationRunTime operatorName operatorRunTime dwellTime itemsCompleted throughput productivity 
		
		const columns = [{name:<IntlMessages id={'GTP.zoneDetails.StationName'}/>, 	options: {
						  filter: true,
						  sort: false,
						  displayRowCheckbox : false,
						}},	
						{name:<IntlMessages id={'GTP.zoneDetails.StationStatus'}/>, 	options: {
						  filter: true,
						  sort: false,
						}},
						{name:<IntlMessages id={'GTP.zoneDetails.StationOverallRunTime'}/>, 	options: {
						  filter: true,
						  sort: false,
						}},						
						{name:<IntlMessages id={'GTP.zoneDetails.OperatorName'}/>, 	options: {
						  filter: true,
						  sort: false,
						}},
						{name:<IntlMessages id={'GTP.zoneDetails.RunTime'}/>, 	options: {
						  filter: true,
						  sort: false,
						}},
						{name:<IntlMessages id={'GTP.zoneDetails.DwellTime'}/>, 	options: {
						  filter: true,
						  sort: false,
						}},
						{name:<IntlMessages id={'GTP.zoneDetails.TaskUnits'}/>, 	options: {
						  filter: true,
						  sort: false,
						}},
						{name:<IntlMessages id={'GTP.zoneDetails.Throughput'}/>, 	options: {
						  filter: true,
						  sort: false,
						}},
						{name:<IntlMessages id={'GTP.zoneDetails.Productivity'}/>, 	options: {
						  filter: true,
						  sort: false,
						}}];
		
				
			
	

		const ReloadButton = () => {
			return (
				<div  className="customReload">
					<button onClick={() => {this.setState({isLoading: true}); this.onReload()}}>
						<span class="fa fa-refresh" aria-hidden="true"></span>
					</button>
				</div>
			);
		};
		  
		const options = {
		  filter: true,
		  filterType: 'dropdown',
		  responsive: 'stacked',
		  displayRowCheckbox : false,
		  customToolbar:  () => <ReloadButton/>
		
		};
		
		function customCell(cellValue, rowIndex, columnIndex) {
		  return (
			<div className="customCheckMain" style={ { display: 'flex', flexDirection: 'columnIndex' } }>
			
			  <div className="customCheck"> <input type="checkbox" id="check" /> { cellValue }</div>
			
			  
			</div>
		  );
		}
		
		const { classes } = this.props;
		const { value } = this.state;
		const labels = ["Picking", "Consolidation", "Decanting", "Cycle Count"];
				  
		const checkBox =() => {
			return (
						
			  <div style={ { display: 'flex', flexDirection: 'column' } }>
					
					<input type="checkbox" id="check" />
			  </div>
			);
		};
		
	     if(this.state.isLoading){
		    return (  
					<NoSsr>
					<div className={"customTab"}>	
							<Spinner />
					</div>
					</NoSsr>  
					  
					  );
		} else {
		return(
		
		
		 <NoSsr>
        <div className={"customTab"}>		
          {(value === "Picking" || value === "Consolidation" || value === "Decanting" || value === "Cycle Count") && <TabContainer>
					
						<ToolkitProvider
							search
						>
							  {
								props => (																					
							<div>
								<div>
									<div className= "headerLeft">
										<div className="customTablebreadcrumb">
											Breadcrumb/breadcrumb
										</div>
										
										<div className="customTableHeader">
											<IntlMessages id={'GTP.zoneDetails.title'} />
										</div>
									</div>
															
									
								</div>								
								<div className="barAndTable">	
								<AppBar position="static" className="customAppBar" style={{fontColor: '#647C72', backgroundColor: '#647C72'}}>
								<div className="tabAndDd">
									<div className="customTabLabels">
										<Tabs value={value} onChange={this.handleChange} className="customAppBar" >
										{labels && labels.map((label, key) => (
											<Tab style={{textTransform: 'uppercase'}} value={label} label={<IntlMessages id={`GTP.operation.${label}`} />} />
										))}
										</Tabs>
									</div>
										
									<div className="customDd text-right">
										<FormControl>
											<Select
											value={this.state.zone}
											onChange={this.handleChangeDropDown}
											name="zone"
											IconComponent={props => (
												<i {...props} className={`material-icons ${props.className}`}>
												  keyboard_arrow_down
												</i>
											)}
											>
											{/* <MenuItem value="all"><IntlMessages id={'GTP.overallWork.ALL ZONES'} /></MenuItem>
											<MenuItem value={10}><IntlMessages id={'GTP.overallWork.ZONE A'} /></MenuItem>
											<MenuItem value={20}><IntlMessages id={'GTP.overallWork.ZONE B'} /></MenuItem>
											<MenuItem value={30}><IntlMessages id={'GTP.overallWork.ZONE C'} /></MenuItem> */}

											<MenuItem value="all">ALL ZONES</MenuItem>
											<MenuItem value={"Zone A"}>ZONE A</MenuItem>
											<MenuItem value={"Zone B"}>ZONE B</MenuItem>
											<MenuItem value={"Zone C"}>ZONE C</MenuItem>
											</Select>
									</FormControl>
									</div>
								</div>
								</AppBar>
							
								
								<InfiniteScroll
									pageStart={0}
									//loadMore={loadFunc}
									hasMore={true}
									loader={<div className="loader" key={0}></div>}
								>
										
								{
								<MUIDataTable
									data={this.state.getGTPStationDetails}
									columns={columns}
									options={options}
								/>}
								
								</InfiniteScroll>
								
							</div> 
						</div>								  
								)
							  }
						</ToolkitProvider>					
					  </TabContainer>}
					  
					</div>
				  </NoSsr> 					
				);
			}
		}
}

export default ZonalNStationDtls;

